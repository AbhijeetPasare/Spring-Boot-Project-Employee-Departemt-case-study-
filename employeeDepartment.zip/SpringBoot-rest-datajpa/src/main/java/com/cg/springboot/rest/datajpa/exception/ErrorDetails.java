package com.cg.springboot.rest.datajpa.exception;

import java.util.Date;

public class ErrorDetails {
	private Date timestamp;
	private String massage;
	private String details;
	
	public Date getTimestamp() {
		return timestamp;
	}
	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}
	public String getMassage() {
		return massage;
	}
	public void setMassage(String massage) {
		this.massage = massage;
	}
	public String getDetails() {
		return details;
	}
	public void setDetails(String details) {
		this.details = details;
	}
	
	public ErrorDetails(Date timestamp, String massage, String details) {
		super();
		this.timestamp = timestamp;
		this.massage = massage;
		this.details = details;
	}
	
	public ErrorDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}

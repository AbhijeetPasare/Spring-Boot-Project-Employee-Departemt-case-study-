package com.cg.springboot.rest.datajpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.springboot.rest.datajpa.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
public List<Employee> findByLastName(String lastName);
}

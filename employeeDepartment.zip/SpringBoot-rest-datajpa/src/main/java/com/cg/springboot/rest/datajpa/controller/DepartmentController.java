package com.cg.springboot.rest.datajpa.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.springboot.rest.datajpa.exception.DepartmentNotFoundException;
import com.cg.springboot.rest.datajpa.model.Department;
import com.cg.springboot.rest.datajpa.model.Employee;
import com.cg.springboot.rest.datajpa.service.DepartmentService;

@RestController
@RequestMapping("/department")
public class DepartmentController {

	@Autowired
	private DepartmentService departmentservice;

	@PostMapping("/new")
	public Department createDepartment(@Valid @RequestBody Department department) {
		return departmentservice.createDepartment(department);

	}

	@GetMapping("/getall")
	public List<Department> getallDepartment() {
		return departmentservice.getAllDepartment();
	}

	@GetMapping("/getbyid/{id}")
	public ResponseEntity<Department> getDepartmentById(@PathVariable(value = "id") Long departmentId)
			throws DepartmentNotFoundException {
		Department department = departmentservice.getDepartmentById(departmentId)
				.orElseThrow(() -> new DepartmentNotFoundException("No Employee found with id :  " + departmentId));
		return ResponseEntity.ok().body(department);
	}

	@PutMapping("/update/{id}")
	public ResponseEntity<Department> updateDepartment(@PathVariable(value = "id") Long departmentId,
			@Valid @RequestBody Department deptDetails) throws DepartmentNotFoundException {
		Department department = departmentservice.getDepartmentById(departmentId)
				.orElseThrow(() -> new DepartmentNotFoundException("No Department found with id :  " + departmentId));
		department.setName(deptDetails.getName());
		department.setLocation(deptDetails.getLocation());
		Department updatedDepartment = departmentservice.updateDepartment(department);
		return ResponseEntity.ok(updatedDepartment); // Response entity means sending respons with data and status
	}

	@DeleteMapping("/department/delete/{id}")
	public Map<String, Boolean> deleteDepartment(@PathVariable(value = "id") Long departmentId)
			throws DepartmentNotFoundException {
		Department department = departmentservice.getDepartmentById(departmentId)
				.orElseThrow(() -> new DepartmentNotFoundException("No Department found with id :  " + departmentId));
		departmentservice.deleteDepartment(department);
		Map<String, Boolean> response = new HashMap<>();
		response.put("Delete", Boolean.TRUE);
		return response;

	}

}

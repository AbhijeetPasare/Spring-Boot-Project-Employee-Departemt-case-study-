package com.cg.springboot.rest.datajpa.service;

import java.util.List;
import java.util.Optional;

import com.cg.springboot.rest.datajpa.model.Department;
import com.cg.springboot.rest.datajpa.model.Employee;

public interface DepartmentService {
	public Department createDepartment(Department department);
	public List<Department> getAllDepartment();
	public Optional<Department> getDepartmentById(Long departmentId);
	public Department updateDepartment(Department department);
	public void deleteDepartment(Department department);

}

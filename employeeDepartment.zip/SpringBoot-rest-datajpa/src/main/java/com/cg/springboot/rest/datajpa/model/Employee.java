package com.cg.springboot.rest.datajpa.model;

import javax.persistence.Entity;
import javax.validation.constraints.NotEmpty;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;
import javax.validation.constraints.Email;

@Entity
public class Employee {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
private long id;
	@NotEmpty(message="First Name is Required")
private String firstName;
	@NotEmpty(message="Last Name is Required")
private String lastName;
	@Email(message="@ annotation requied")
	@NotEmpty(message="Email ID is Required")
private String emailId;
	
@ManyToOne
@JoinColumn(name="dept_id")
private Department department;

public Department getDepartment() {
	return department;
}
public void setDepartment(Department department) {
	this.department = department;
}
public long getId() {
	return id;
}
public void setId(long id) {
	this.id = id;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}
public String getEmailId() {
	return emailId;
}
public void setEmailId(String emailId) {
	this.emailId = emailId;
}
public Employee(long id, @NotEmpty(message = "First Name is Required") String firstName,
		@NotEmpty(message = "Last Name is Required") String lastName,
		@Email(message = "@ annotation requied") @NotEmpty(message = "Email ID is Required") String emailId,
		Department department) {
	super();
	this.id = id;
	this.firstName = firstName;
	this.lastName = lastName;
	this.emailId = emailId;
	this.department = department;
}
public Employee() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Employee [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", emailId=" + emailId
			+ ", department=" + department + "]";
}



}

package com.cg.springboot.rest.datajpa.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cg.springboot.rest.datajpa.exception.DepartmentNotFoundException;
import com.cg.springboot.rest.datajpa.exception.EmployeeNotFoundException;
import com.cg.springboot.rest.datajpa.model.Department;
import com.cg.springboot.rest.datajpa.model.Employee;
import com.cg.springboot.rest.datajpa.service.DepartmentService;
import com.cg.springboot.rest.datajpa.service.EmployeeService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@RequestMapping("/api")
public class EmployeeController {

	@Autowired
	private EmployeeService employeeService;       //EmployeeService employeeService = new EmployeeService();
	
	@Autowired
	private DepartmentService departmentService;    
	
	@PostMapping("/employee/new")
	public Employee createEmployee(@Valid @RequestBody Employee employee) throws DepartmentNotFoundException {
		Long deptId=employee.getDepartment().getId();
		Department department=departmentService.getDepartmentById(deptId).orElseThrow(()->
		new DepartmentNotFoundException("No Department found with id :  " + deptId));
		return employeeService.createEmployee(employee);
	}
	
	@GetMapping("/employee/all")
	public List<Employee>getallEmployees(){
		return employeeService.getAllEmployees();
	}
	
		@GetMapping("/employee/id/{id}")
	    public ResponseEntity<Employee> getEmployeeById(@PathVariable (value="id") Long employeeId)
			throws EmployeeNotFoundException{
			Employee employee=employeeService.getEmployeeById(employeeId).orElseThrow(()->
			new EmployeeNotFoundException("No Employee found with id :  " + employeeId));
			return ResponseEntity.ok().body(employee);
				
	}
		
		@GetMapping("/employee/lastname/{lastName}")
		public List<Employee> getAllEmployeeByLastName(@PathVariable(value="lastName") String lastname){
			return employeeService.getAllEmployeeByLastName(lastname);
		}
		
		@PutMapping("/employee/update/{id}")
		public ResponseEntity<Employee> updateEmployee(@PathVariable (value="id") Long employeeId ,@Valid @RequestBody Employee empDetails)
			throws EmployeeNotFoundException{
			Employee employee=employeeService.getEmployeeById(employeeId).orElseThrow(()->
			new EmployeeNotFoundException("No Employee found with id :  " + employeeId));
			employee.setFirstName(empDetails.getFirstName());
			employee.setLastName(empDetails.getLastName());
			employee.setEmailId(empDetails.getEmailId());
			Employee updatedEmployee=employeeService.updateEmployee(employee);
			return ResponseEntity.ok(updatedEmployee);                       //Response entity means sending respons with data and status
		}
		
		@DeleteMapping("/employee/delete/{id}")
		public Map<String,Boolean> deleteEmployee(@PathVariable (value="id")Long employeeId)throws EmployeeNotFoundException{
			Employee employee=employeeService.getEmployeeById(employeeId).orElseThrow(()->
			new EmployeeNotFoundException("No Employee found with id :  " + employeeId));
			employeeService.deleteEmployee(employee);
			Map<String , Boolean> response =new HashMap<>();
			response.put("Delete", Boolean.TRUE);
			return response;

		}
		@ResponseStatus(HttpStatus.BAD_REQUEST)
		@ExceptionHandler(MethodArgumentNotValidException.class)
		public Map<String, String> handleMethodArgNotValid(MethodArgumentNotValidException ex){
			Map<String, String> errors=new HashMap<>();
			ex.getBindingResult().getFieldErrors().forEach(error -> errors.put(error.getField(), error.getDefaultMessage()));
			return errors;
		}
}

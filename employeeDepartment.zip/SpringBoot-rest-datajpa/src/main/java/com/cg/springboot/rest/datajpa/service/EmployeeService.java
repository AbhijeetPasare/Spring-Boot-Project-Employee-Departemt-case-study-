package com.cg.springboot.rest.datajpa.service;



import java.util.List;
import java.util.Optional;

import com.cg.springboot.rest.datajpa.model.Employee;


public interface EmployeeService {
public Employee createEmployee(Employee employee);
public List<Employee> getAllEmployees();
public Optional<Employee> getEmployeeById(Long employeeId);
public List<Employee> getAllEmployeeByLastName(String lastName);
public Employee updateEmployee(Employee employee);
public void deleteEmployee(Employee employee);
}

package com.cg.springboot.rest.datajpa.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springboot.rest.datajpa.model.Department;
import com.cg.springboot.rest.datajpa.repository.DepartmentRepository;

@Service
public class DepartmentServiceImpl implements DepartmentService{
	
	@Autowired
	private DepartmentRepository departmentrepository;

	@Override
	public Department createDepartment(Department department) {
		// TODO Auto-generated method stub
		return departmentrepository.save(department);
	}

	@Override
	public List<Department> getAllDepartment() {
		// TODO Auto-generated method stub
		return departmentrepository.findAll();
	}

	@Override
	public Optional<Department> getDepartmentById(Long departmentId) {
		// TODO Auto-generated method stub
		return departmentrepository.findById(departmentId);
	}

	@Override
	public Department updateDepartment(Department department) {
		// TODO Auto-generated method stub
		return departmentrepository.save(department);
	}

	@Override
	public void deleteDepartment(Department department) {
		// TODO Auto-generated method stub
		departmentrepository.delete(department);
	
	
	}
	
	
	
	

}

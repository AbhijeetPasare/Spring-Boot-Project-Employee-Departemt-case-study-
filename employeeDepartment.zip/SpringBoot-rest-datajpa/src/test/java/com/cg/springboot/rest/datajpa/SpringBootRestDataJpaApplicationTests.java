package com.cg.springboot.rest.datajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRestDataJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}

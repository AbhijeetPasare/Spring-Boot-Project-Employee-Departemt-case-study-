package com.cg.springbootrestdatajpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootRestDatajpaApplicationTests {

	@Test
	void contextLoads() {
	}

}

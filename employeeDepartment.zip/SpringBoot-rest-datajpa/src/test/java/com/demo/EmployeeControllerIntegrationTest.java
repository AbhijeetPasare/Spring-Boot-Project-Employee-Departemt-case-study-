package com.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;

import com.cg.springboot.rest.datajpa.SpringBootRestDataJpaApplication;
import com.cg.springboot.rest.datajpa.model.Department;
import com.cg.springboot.rest.datajpa.model.Employee;

@SpringBootTest(classes = SpringBootRestDataJpaApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class EmployeeControllerIntegrationTest {

	@Autowired
	private TestRestTemplate restTemplate;

	@LocalServerPort
	private int port;

	private String getRootUrl() {
		return "http://localhost:" + port + "/api";

	}

	@Test
	public void testCreateEmployee() {
		Employee employee = new Employee();
		employee.setFirstName("Abhieet");
		employee.setLastName("Pasare");
		employee.setEmailId("pasareabhijeet92@gmail.com");
		Department dept = new Department();
		dept.setId(6);
		employee.setDepartment(dept);
		ResponseEntity<Employee> postResponse = restTemplate.postForEntity(getRootUrl() + "/employee/new", employee,
				Employee.class);
		assertNotNull(postResponse);
		assertNotNull(postResponse.getBody());
	}

	@Test
	public void testGetAllEmployees() {

		HttpHeaders headers = new HttpHeaders(); // Represent an HTTP request or response entity, consisting of headers
												// and body
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);
		ResponseEntity<String> response = restTemplate.exchange(getRootUrl() + "/employee/all", HttpMethod.GET, entity,
				String.class);
		assertNotNull(response.getBody());
//		List<ResponseEntity> nameslist = new ArrayList<>();
//		Serializable iterator = restTemplate.getForObject(getRootUrl() + "/employee/all", String.class);
		System.out.println(response);
	
	}

	@Test
	public void testGetEmployeeById() {
		Scanner sn =new Scanner (System.in);
		System.out.println("Plz Enter your Id : ");
		long id=sn.nextLong();
		Employee employee = restTemplate.getForObject(getRootUrl() + "/employee/id/" + id, Employee.class);
		System.out.println("Emp FirstName : " + employee.getFirstName());
		System.out.println("Emp LastName : " + employee.getLastName());
		System.out.println("Emp EmailId : " + employee.getEmailId());
		System.out.println("Emp Department : " + employee.getDepartment());
		assertNotNull(employee);
	}

	@Test
	public void testUpdateEmployee() {
		Employee employee = restTemplate.getForObject(getRootUrl() + "/employee/id/9", Employee.class);
		employee.setFirstName("Pranav");
		employee.setLastName("Surase");
		employee.setEmailId("pranav@gmail.com");
		restTemplate.put(getRootUrl() + "/employee/update/9", employee);
		Employee updatedEmployee = restTemplate.getForObject(getRootUrl() + "/employee/id/9", Employee.class);
		assertNotNull(updatedEmployee);
	}

	@Test
	public void testDeleteEmployee() {
		Employee employee = restTemplate.getForObject(getRootUrl() + "/employee/id/9", Employee.class);
		assertNotNull(employee);
		restTemplate.delete(getRootUrl() + "/employee/delete/9");
		try {
			employee = restTemplate.getForObject(getRootUrl() + "/employee/id/9", Employee.class);
		} catch (final HttpClientErrorException e) {
			assertEquals(e.getStatusCode(), HttpStatus.NOT_FOUND);
		}
	}

}
